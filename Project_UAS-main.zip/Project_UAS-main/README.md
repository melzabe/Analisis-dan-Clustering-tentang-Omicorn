# Project UAS
**Kapsel Kelompok Omicron**

1. Ayu Kinasih Yuliawati - 11180940000001
2. Esti Choerunnisa - 11180940000004
3. Nanda Aprilia - 11180940000012
4. Anggi Indah Lestari - 11180940000023
5. Melza Berliana - 11180940000028
